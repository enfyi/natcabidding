function themeBaseUrl() {
  const script = document.currentScript || document.querySelector('script[src*="/natca-zla-theme/script.js"]');
  if (script?.src) return script.src.replace(/\/script\.js(?:\?.*)?$/, "");

  const stylesheet = document.querySelector('link[href*="/natca-zla-theme/style.css"]');
  return stylesheet?.href ? stylesheet.href.replace(/\/style\.css(?:\?.*)?$/, "") : "";
}

function headerIsVisible(header) {
  if (!header) return false;
  const styles = window.getComputedStyle(header);
  return styles.display !== "none" && styles.visibility !== "hidden" && styles.opacity !== "0" && header.offsetHeight > 0;
}

function headerHasContent(header) {
  return Boolean(header?.querySelector(".brand img") && header.querySelectorAll(".site-nav a").length >= 5);
}

function footerIsVisible(footer) {
  if (!footer) return false;
  const styles = window.getComputedStyle(footer);
  return styles.display !== "none" && styles.visibility !== "hidden" && styles.opacity !== "0" && footer.offsetHeight > 0;
}

function footerHasContent(footer) {
  return Boolean(footer?.querySelector(".footer-inner") && footer.querySelectorAll("a").length >= 5);
}

function createFallbackHeader() {
  const header = document.createElement("header");
  const base = themeBaseUrl();

  header.className = "site-header site-header-fallback";
  header.innerHTML = `
    <a class="brand" href="/#zla-home" aria-label="NATCA ZLA home">
      <img src="${base}/assets/logo-5v2a.png" alt="NATCA Los Angeles Center" />
      <span>
        <strong>ZLA</strong>
        <small>Los Angeles Center</small>
      </span>
    </a>
    <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="site-nav">
      <span></span>
      <span></span>
      <span></span>
    </button>
    <nav id="site-nav" class="site-nav" aria-label="Primary navigation">
      <a href="/#zla-home">Home</a>
      <a href="/#events">Events</a>
      <a href="/#reps">Reps</a>
      <a href="/training/">Training</a>
      <a href="/#lse">LSC</a>
      <span class="nav-item has-submenu">
        <a href="/#airspace">Airspace</a>
        <span class="submenu">
          <a href="https://natcazla.com/ap.html">Airspace Tracker</a>
        </span>
      </span>
      <a href="/#contact">Contact</a>
    </nav>
    <a class="header-action" href="/#contact">Contact</a>
  `;

  document.body.insertBefore(header, document.body.firstChild);
  return header;
}

function createFallbackFooter() {
  const footer = document.createElement("footer");
  const base = themeBaseUrl();

  footer.className = "site-footer site-footer-fallback";
  footer.innerHTML = `
    <div class="footer-inner">
      <div class="footer-brand">
        <div>
          <img src="${base}/assets/logo-5v2a.png" alt="" />
          <div>
            <span>NATCA ZLA</span>
            <small>Los Angeles Center</small>
          </div>
        </div>
        <p>A local member hub for ZLA updates, events, training resources, LSC information, and airspace procedure coordination.</p>
      </div>
      <nav class="footer-links" aria-label="Footer site links">
        <h2>Local</h2>
        <a href="/#events">Events</a>
        <a href="/#reps">Representatives</a>
        <a href="/training/">Training</a>
        <a href="/#lse">LSC</a>
        <a href="https://natcazla.com/ap.html">Airspace Tracker</a>
      </nav>
      <nav class="footer-links" aria-label="External links">
        <h2>External</h2>
        <a href="https://www.natca.org/" target="_blank" rel="noopener">NATCA National</a>
        <a href="https://www.faa.gov/" target="_blank" rel="noopener">FAA</a>
        <a href="https://www.faa.gov/air_traffic" target="_blank" rel="noopener">FAA Air Traffic</a>
        <a href="https://www.osha.gov/" target="_blank" rel="noopener">OSHA</a>
        <a href="#">Add link</a>
      </nav>
      <div class="footer-contact">
        <h2>Facility</h2>
        <address>2555 E. Ave P<br />Palmdale, CA 93550<br />Los Angeles ARTCC, Palmdale, California</address>
        <a href="mailto:zla@natca.net">zla@natca.net</a>
      </div>
    </div>
    <div class="footer-bottom">
      <span>&copy; ${new Date().getFullYear()} NATCA ZLA</span>
      <span>Los Angeles Center</span>
    </div>
  `;

  document.body.append(footer);
  return footer;
}

function ensureThemeHeader() {
  let header = document.querySelector(".site-header");
  if (!header) {
    return createFallbackHeader();
  }

  header.removeAttribute("hidden");
  header.style.setProperty("display", "grid", "important");
  header.style.setProperty("visibility", "visible", "important");
  header.style.setProperty("opacity", "1", "important");
  return header;
}

function ensureThemeFooter() {
  let footer = document.querySelector(".site-footer");
  if (!footerIsVisible(footer) || !footerHasContent(footer)) {
    footer?.remove();
    footer = createFallbackFooter();
  }
  return footer;
}

ensureThemeHeader();
ensureThemeFooter();

let navToggle = document.querySelector(".nav-toggle");
let siteNav = document.querySelector(".site-nav");
let navLinks = [...document.querySelectorAll(".site-nav a")];
let sections = navLinks
  .map((link) => link.getAttribute("href"))
  .filter((href) => href?.startsWith("#"))
  .map((href) => document.querySelector(href))
  .filter(Boolean);

function hideElement(element) {
  element.setAttribute("hidden", "");
  element.style.setProperty("display", "none", "important");
}

function isThemeHeaderElement(element) {
  return (
    element.matches("#wpadminbar, .site-header, .site-header *") ||
    Boolean(element.querySelector(".site-header"))
  );
}

function restoreThemeHeader() {
  const header = ensureThemeHeader();
  if (!header) return;

  header.removeAttribute("hidden");
  header.style.setProperty("display", "grid", "important");
  header.style.setProperty("visibility", "visible", "important");
  header.style.setProperty("opacity", "1", "important");

  header.querySelectorAll(".brand, .site-nav, .nav-toggle, .header-action").forEach((element) => {
    element.removeAttribute("hidden");
    element.style.setProperty("visibility", "visible", "important");
    element.style.setProperty("opacity", "1", "important");
  });

  const nav = header.querySelector(".site-nav");
  const contact = header.querySelector(".header-action");
  if (window.matchMedia("(min-width: 981px)").matches) {
    nav?.style.setProperty("display", "flex", "important");
    contact?.style.setProperty("display", "inline-flex", "important");
  }
}

function restoreThemeFooter() {
  const footer = ensureThemeFooter();
  if (!footer) return;

  footer.removeAttribute("hidden");
  footer.style.setProperty("display", "block", "important");
  footer.style.setProperty("visibility", "visible", "important");
  footer.style.setProperty("opacity", "1", "important");
}

function legacySelector() {
  return [
    ".pagelayer-row:first-child",
    ".pagelayer-section:first-child",
    ".pagelayer-header",
    ".pagelayer-menu",
    ".pagelayer-nav-menu",
    ".pagelayer-footer",
    "body > header:not(.site-header)",
    ".site-content header:not(.site-header)",
    "main header:not(.site-header)",
    ".wp-block-cover:first-child",
    ".wp-block-image:first-child",
    ".page-header",
    ".page-title-section",
    ".banner",
    ".hero-banner",
    ".hero-section",
    ".home-slider",
    ".slider",
    ".slideshow",
    ".header-image",
    ".custom-header",
    ".wp-custom-header",
    ".featured-image",
    ".post-thumbnail",
    '[class*="pagelayer"][class*="header"]',
    '[class*="pagelayer"][class*="menu"]',
    '[class*="pagelayer"][class*="footer"]',
  ].join(", ");
}

function hideLegacyPageBuilderContent() {
  document.querySelectorAll(legacySelector()).forEach((element) => {
    if (!isThemeHeaderElement(element)) hideElement(element);
  });
}

function isLegacyHomeElement(element) {
  if (isThemeHeaderElement(element) || element.matches("script, style, link")) return false;

  return element.matches(legacySelector()) || /WELCOME\s+TO\s+NATCA\s+ZLA/i.test(element.textContent || "");
}

function hideLegacyHomeContent() {
  const homeSection = document.querySelector("#zla-home");
  restoreThemeHeader();
  restoreThemeFooter();
  hideLegacyPageBuilderContent();
  if (!homeSection) return;

  let previous = homeSection.previousElementSibling;
  while (previous) {
    const current = previous;
    previous = previous.previousElementSibling;
    if (isLegacyHomeElement(current)) hideElement(current);
  }

  const main = homeSection.closest("main");
  if (!main) return;

  let sibling = main.previousElementSibling;
  while (sibling) {
    const current = sibling;
    sibling = sibling.previousElementSibling;

    if (isThemeHeaderElement(current)) break;
    if (isLegacyHomeElement(current)) hideElement(current);
  }

  restoreThemeHeader();
  restoreThemeFooter();
}

hideLegacyHomeContent();
window.addEventListener("load", hideLegacyHomeContent);
window.addEventListener("load", () => {
  restoreThemeHeader();
  restoreThemeFooter();
  window.setTimeout(restoreThemeHeader, 250);
  window.setTimeout(restoreThemeFooter, 250);
  window.setTimeout(restoreThemeHeader, 1000);
  window.setTimeout(restoreThemeFooter, 1000);
});

navToggle?.addEventListener("click", () => {
  const isOpen = siteNav.classList.toggle("open");
  navToggle.setAttribute("aria-expanded", String(isOpen));
});

navLinks.forEach((link) => {
  link.addEventListener("click", () => {
    siteNav.classList.remove("open");
    navToggle?.setAttribute("aria-expanded", "false");
  });
});

if ("IntersectionObserver" in window) {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        navLinks.forEach((link) => {
          link.classList.toggle("active", link.getAttribute("href") === `#${entry.target.id}`);
        });
      });
    },
    { rootMargin: "-45% 0px -50% 0px", threshold: 0 }
  );

  sections.forEach((section) => observer.observe(section));
}

document.querySelector(".contact-section .contact-form")?.addEventListener("submit", (event) => {
  event.preventDefault();
  const note = event.currentTarget.querySelector(".form-note");
  note.textContent = "Message prepared. Connect this form to your preferred WordPress form plugin when ready.";
});
