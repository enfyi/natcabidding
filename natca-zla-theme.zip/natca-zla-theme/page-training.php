<?php
/*
Template Name: Training
*/
get_header();
?>

<main class="page-main">
  <section class="section page-hero">
    <div class="section-heading">
      <p>Training // ZLA</p>
      <h1>Training Information</h1>
    </div>
    <p>
      A single home for current NATCA ZLA training references, MOU links, briefings, and
      classroom notes. Add and edit resources from the Training Resources / MOUs area in
      WordPress admin.
    </p>
  </section>

  <section class="section training-detail">
    <div class="section-heading">
      <p>Current Resources</p>
      <h2>Member References</h2>
    </div>
    <div class="resource-detail-grid">
      <?php
      $resources = new WP_Query([
          'post_type' => 'zla_resource',
          'posts_per_page' => -1,
          'orderby' => 'date',
          'order' => 'ASC',
      ]);
      ?>
      <?php if ($resources->have_posts()) : ?>
        <?php while ($resources->have_posts()) : $resources->the_post(); ?>
          <?php
          $category = get_post_meta(get_the_ID(), '_zla_resource_category', true) ?: 'Resource';
          $resource_url = get_post_meta(get_the_ID(), '_zla_resource_url', true) ?: get_permalink();
          ?>
          <article class="doc-card">
            <span><?php echo esc_html($category); ?></span>
            <h3><?php the_title(); ?></h3>
            <p><?php echo esc_html(wp_trim_words(wp_strip_all_tags(get_the_content()), 28)); ?></p>
            <a href="<?php echo esc_url($resource_url); ?>">Open resource</a>
          </article>
        <?php endwhile; wp_reset_postdata(); ?>
      <?php else : ?>
        <p class="empty-row">No training resources are currently listed.</p>
      <?php endif; ?>
    </div>
  </section>
</main>

<?php get_footer(); ?>
