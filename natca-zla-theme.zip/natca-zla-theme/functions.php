<?php
/**
 * NATCA ZLA theme setup and content types.
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once get_template_directory() . '/template-tags.php';

function natca_zla_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', [
        'height' => 587,
        'width' => 503,
        'flex-height' => true,
        'flex-width' => true,
    ]);

    register_nav_menus([
        'primary' => __('Primary Navigation', 'natca-zla'),
    ]);
}
add_action('after_setup_theme', 'natca_zla_setup');

function natca_zla_assets() {
    wp_enqueue_style(
        'natca-zla-fonts',
        'https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Montserrat:wght@600;700;800;900&family=Open+Sans:wght@400;600;700&display=swap',
        [],
        null
    );
    wp_enqueue_style('natca-zla-style', get_stylesheet_uri(), ['natca-zla-fonts'], wp_get_theme()->get('Version'));
    wp_enqueue_script('natca-zla-script', get_template_directory_uri() . '/script.js', [], wp_get_theme()->get('Version'), true);
}
add_action('wp_enqueue_scripts', 'natca_zla_assets');

function natca_zla_register_post_types() {
    register_post_type('zla_event', [
        'labels' => [
            'name' => __('Events', 'natca-zla'),
            'singular_name' => __('Event', 'natca-zla'),
            'add_new_item' => __('Add New Event', 'natca-zla'),
            'edit_item' => __('Edit Event', 'natca-zla'),
        ],
        'public' => true,
        'menu_icon' => 'dashicons-calendar-alt',
        'supports' => ['title', 'editor'],
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'events'],
    ]);

    register_post_type('zla_resource', [
        'labels' => [
            'name' => __('Training Resources / MOUs', 'natca-zla'),
            'singular_name' => __('Training Resource', 'natca-zla'),
            'add_new_item' => __('Add New Resource', 'natca-zla'),
            'edit_item' => __('Edit Resource', 'natca-zla'),
        ],
        'public' => true,
        'menu_icon' => 'dashicons-media-document',
        'supports' => ['title', 'editor'],
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'training-resources'],
    ]);

    register_post_type('zla_rep', [
        'labels' => [
            'name' => __('Representatives', 'natca-zla'),
            'singular_name' => __('Representative', 'natca-zla'),
            'add_new_item' => __('Add New Representative', 'natca-zla'),
            'edit_item' => __('Edit Representative', 'natca-zla'),
        ],
        'public' => true,
        'menu_icon' => 'dashicons-groups',
        'supports' => ['title', 'editor'],
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'representatives'],
    ]);

}
add_action('init', 'natca_zla_register_post_types');

function natca_zla_meta_boxes() {
    add_meta_box('natca_zla_event_details', __('Event Details', 'natca-zla'), 'natca_zla_event_meta_box', 'zla_event', 'normal', 'high');
    add_meta_box('natca_zla_resource_details', __('Resource Details', 'natca-zla'), 'natca_zla_resource_meta_box', 'zla_resource', 'normal', 'high');
    add_meta_box('natca_zla_rep_details', __('Representative Details', 'natca-zla'), 'natca_zla_rep_meta_box', 'zla_rep', 'normal', 'high');
}
add_action('add_meta_boxes', 'natca_zla_meta_boxes');

function natca_zla_field($post, $key, $label, $type = 'text', $placeholder = '') {
    $value = get_post_meta($post->ID, $key, true);
    ?>
    <p>
        <label for="<?php echo esc_attr($key); ?>"><strong><?php echo esc_html($label); ?></strong></label><br />
        <input
            id="<?php echo esc_attr($key); ?>"
            name="<?php echo esc_attr($key); ?>"
            type="<?php echo esc_attr($type); ?>"
            value="<?php echo esc_attr($value); ?>"
            placeholder="<?php echo esc_attr($placeholder); ?>"
            style="width:100%;max-width:520px;"
        />
    </p>
    <?php
}

function natca_zla_event_meta_box($post) {
    wp_nonce_field('natca_zla_save_meta', 'natca_zla_meta_nonce');
    natca_zla_field($post, '_zla_event_date', 'Date', 'date');
    natca_zla_field($post, '_zla_event_time', 'Time', 'text', '1330');
    natca_zla_field($post, '_zla_event_location', 'Location', 'text', 'A120');
}

function natca_zla_resource_meta_box($post) {
    wp_nonce_field('natca_zla_save_meta', 'natca_zla_meta_nonce');
    natca_zla_field($post, '_zla_resource_category', 'Category', 'text', 'MOUs');
    natca_zla_field($post, '_zla_resource_url', 'Document / Resource URL', 'url', 'https://...');
}

function natca_zla_rep_meta_box($post) {
    wp_nonce_field('natca_zla_save_meta', 'natca_zla_meta_nonce');
    natca_zla_field($post, '_zla_rep_role', 'Role', 'text', 'Facility Representative');
    natca_zla_field($post, '_zla_rep_initials', 'Initials', 'text', 'FR');
    natca_zla_field($post, '_zla_rep_phone', 'Phone', 'text', '(661) 000-0000');
    natca_zla_field($post, '_zla_rep_email', 'Email', 'email', 'name@natca.net');
}

function natca_zla_save_meta($post_id) {
    if (!isset($_POST['natca_zla_meta_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['natca_zla_meta_nonce'])), 'natca_zla_save_meta')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    $fields = [
        '_zla_event_date',
        '_zla_event_time',
        '_zla_event_location',
        '_zla_resource_category',
        '_zla_resource_url',
        '_zla_rep_role',
        '_zla_rep_initials',
        '_zla_rep_phone',
        '_zla_rep_email',
    ];

    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, $field, sanitize_text_field(wp_unslash($_POST[$field])));
        }
    }
}
add_action('save_post', 'natca_zla_save_meta');

function natca_zla_customize_register($wp_customize) {
    $wp_customize->add_section('natca_zla_settings', [
        'title' => __('NATCA ZLA Settings', 'natca-zla'),
        'priority' => 35,
    ]);

    $settings = [
        'natca_zla_contact_email' => ['Contact Email', 'zla@natca.net'],
        'natca_zla_facility' => ['Facility Text', 'Los Angeles ARTCC, Palmdale, California'],
        'natca_zla_facebook_url' => ['Facebook URL', ''],
        'natca_zla_instagram_url' => ['Instagram URL', ''],
        'natca_zla_ap_tracker_url' => ['Airspace Tracker URL', 'https://natcazla.com/ap.html'],
    ];

    foreach ($settings as $id => $setting) {
        [$label, $default] = $setting;
        $is_url = strpos($id, 'url') !== false;
        $wp_customize->add_setting($id, [
            'default' => $default,
            'sanitize_callback' => $is_url ? 'esc_url_raw' : 'sanitize_text_field',
        ]);
        $wp_customize->add_control($id, [
            'label' => __($label, 'natca-zla'),
            'section' => 'natca_zla_settings',
            'type' => $is_url ? 'url' : 'text',
        ]);
    }
}
add_action('customize_register', 'natca_zla_customize_register');

function natca_zla_upcoming_events($limit = 4) {
    return new WP_Query([
        'post_type' => 'zla_event',
        'posts_per_page' => $limit,
        'meta_key' => '_zla_event_date',
        'orderby' => 'meta_value',
        'order' => 'ASC',
        'meta_query' => [
            [
                'key' => '_zla_event_date',
                'value' => current_time('Y-m-d'),
                'compare' => '>=',
                'type' => 'DATE',
            ],
        ],
    ]);
}

function natca_zla_seed_content() {
    if (get_option('natca_zla_seeded')) {
        return;
    }

    $events = [
        ['ZLA Membership Meeting', '2026-05-20', '1330', 'A120', 'Monthly membership meeting.'],
        ['ERAM Refresher', '2026-05-22', '0900', 'Training Room', 'Required refresher materials and discussion.'],
        ['Professional Standards Brief', '2026-05-29', '1000', 'Teams', 'Professional Standards updates and Q&A.'],
        ['OWCP Info Session', '2026-06-03', '1330', 'A120', 'OWCP claims and benefits overview.'],
        ['Fatigue Risk Management', '2026-06-10', '0900', 'Training Room', 'Fatigue awareness training.'],
    ];
    foreach ($events as [$title, $date, $time, $location, $content]) {
        $post_id = wp_insert_post([
            'post_type' => 'zla_event',
            'post_status' => 'publish',
            'post_title' => $title,
            'post_content' => $content,
        ]);
        update_post_meta($post_id, '_zla_event_date', $date);
        update_post_meta($post_id, '_zla_event_time', $time);
        update_post_meta($post_id, '_zla_event_location', $location);
    }

    $resources = [
        ['Art 18, 24, 32, 34 MOUs', 'MOUs', 'Core MOU references for member questions and local coordination.'],
        ['Fatigue MOU', 'Fatigue', 'Fatigue guidance, protections, and awareness items for safe operations.'],
        ['Additional Training Resource', 'Pending', 'Reserved for the next resource you identify.'],
    ];
    foreach ($resources as [$title, $category, $content]) {
        $post_id = wp_insert_post([
            'post_type' => 'zla_resource',
            'post_status' => 'publish',
            'post_title' => $title,
            'post_content' => $content,
        ]);
        update_post_meta($post_id, '_zla_resource_category', $category);
    }

    $reps = [
        ['Martin Ramirez', 'Facility Representative', 'FR', 'Primary local representative for facility-wide member issues and coordination.'],
        ['Area Representatives', 'Area Representatives', 'AR', 'Area-level support for operational questions, schedules, and local concerns.'],
        ['Training Representative', 'Training Representative', 'TR', 'Training updates, development resources, and classroom coordination.'],
        ['LSE Contact', 'LSE Contact', 'LS', 'Local safety engagement, lesson sharing, and safety reporting support.'],
    ];
    foreach ($reps as [$title, $role, $initials, $content]) {
        $post_id = wp_insert_post([
            'post_type' => 'zla_rep',
            'post_status' => 'publish',
            'post_title' => $title,
            'post_content' => $content,
        ]);
        update_post_meta($post_id, '_zla_rep_role', $role);
        update_post_meta($post_id, '_zla_rep_initials', $initials);
    }

    update_option('natca_zla_seeded', 1);
}
add_action('after_switch_theme', 'natca_zla_seed_content');
