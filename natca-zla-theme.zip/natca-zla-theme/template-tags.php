<?php
if (!defined('ABSPATH')) {
    exit;
}

function natca_zla_fallback_menu($args = []) {
    ?>
    <ul class="site-nav-list">
      <li><a href="<?php echo esc_url(home_url('/#zla-home')); ?>">Home</a></li>
      <li><a href="<?php echo esc_url(home_url('/#events')); ?>">Events</a></li>
      <li><a href="<?php echo esc_url(home_url('/#reps')); ?>">Reps</a></li>
      <li><a href="<?php echo esc_url(home_url('/training/')); ?>">Training</a></li>
      <li><a href="<?php echo esc_url(home_url('/#lse')); ?>">LSC</a></li>
      <li class="menu-item-has-children">
        <a href="<?php echo esc_url(home_url('/#airspace')); ?>">Airspace</a>
        <ul class="sub-menu">
          <li><a href="https://natcazla.com/ap.html">Airspace Tracker</a></li>
        </ul>
      </li>
      <li><a href="<?php echo esc_url(home_url('/#contact')); ?>">Contact</a></li>
    </ul>
    <?php
}
