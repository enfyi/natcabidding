<!doctype html>
<html <?php language_attributes(); ?>>
  <head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <?php if (! has_site_icon()) : ?>
      <link rel="icon" href="<?php echo esc_url(get_template_directory_uri() . '/assets/logo-5v2a.png'); ?>" type="image/png" />
      <link rel="apple-touch-icon" href="<?php echo esc_url(get_template_directory_uri() . '/assets/logo-5v2a.png'); ?>" />
    <?php endif; ?>
    <?php wp_head(); ?>
  </head>
  <body <?php body_class(); ?>>
    <?php wp_body_open(); ?>
    <header class="site-header">
      <a class="brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php bloginfo('name'); ?>">
        <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/logo-5v2a.png'); ?>" alt="NATCA Los Angeles Center" />
        <span>
          <strong>ZLA</strong>
          <small>Los Angeles Center</small>
        </span>
      </a>

      <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="site-nav">
        <span></span>
        <span></span>
        <span></span>
      </button>

      <nav id="site-nav" class="site-nav" aria-label="<?php esc_attr_e('Primary navigation', 'natca-zla'); ?>">
        <?php
        wp_nav_menu([
            'theme_location' => 'primary',
            'container' => false,
            'fallback_cb' => 'natca_zla_fallback_menu',
            'menu_class' => 'site-nav-list',
            'depth' => 2,
        ]);
        ?>
      </nav>

      <a class="header-action" href="<?php echo esc_url(home_url('/#contact')); ?>">Contact</a>
    </header>
