<?php get_header(); ?>

<main class="page-main">
  <section class="section page-hero">
    <div class="section-heading">
      <p><?php bloginfo('name'); ?></p>
      <h1><?php single_post_title(); ?></h1>
    </div>
    <p><?php bloginfo('description'); ?></p>
  </section>

  <section class="section">
    <div class="resource-detail-grid">
      <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>
          <?php $post_type_object = get_post_type_object(get_post_type()); ?>
          <article class="doc-card">
            <span><?php echo esc_html($post_type_object ? $post_type_object->labels->singular_name : 'Post'); ?></span>
            <h3><?php the_title(); ?></h3>
            <p><?php echo esc_html(wp_trim_words(wp_strip_all_tags(get_the_excerpt() ?: get_the_content()), 28)); ?></p>
            <a href="<?php the_permalink(); ?>">Read more</a>
          </article>
        <?php endwhile; ?>
      <?php else : ?>
        <p class="empty-row">Nothing is published here yet.</p>
      <?php endif; ?>
    </div>
  </section>
</main>

<?php get_footer(); ?>
