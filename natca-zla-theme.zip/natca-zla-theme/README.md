# NATCA ZLA WordPress Theme

Classic custom WordPress theme for the NATCA ZLA website.

## Install

1. Copy the `natca-zla-theme` folder into `wp-content/themes/`.
2. In WordPress admin, go to Appearance -> Themes and activate `NATCA ZLA`.
3. Create a page with slug `training` to use the included Training template/page.
4. Go to Appearance -> Menus and assign your menu to `Primary Navigation`, or use the built-in fallback links.
5. Go to Appearance -> Customize -> NATCA ZLA Settings to set contact email, facility text, Facebook, Instagram, and Airspace Tracker URL.

## Editing Content

The theme adds WordPress admin sections for:

- Events: add date, time, and location. The homepage automatically shows the next 4 future events.
- Training Resources / MOUs: add MOUs, PDFs, links, and descriptions.
- Representatives: add reps, roles, initials, phone, and email.
- Airspace Tracker: set the tracker URL in the Customizer. The default is `https://natcazla.com/ap.html`.

The theme seeds starter content when first activated.
