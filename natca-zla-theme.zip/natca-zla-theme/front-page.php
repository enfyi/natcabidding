<?php get_header(); ?>

<main>
  <?php
  $events = natca_zla_upcoming_events(4);
  $next_event = $events->have_posts() ? $events->posts[0] : null;
  ?>

  <section id="zla-home" class="hero section">
    <div class="hero-copy">
      <h1>NATCA ZLA</h1>
      <p class="hero-lede">
        Proudly representing the controllers of Los Angeles Air Route Traffic Control Center.
      </p>
      <p>
        A clean member hub for local updates, upcoming events, training resources, LSC
        information, and airspace work affecting ZLA controllers.
      </p>
      <div class="hero-actions">
        <a class="button primary" href="#reps">Meet Your Reps</a>
        <a class="button secondary" href="#events">View Events</a>
      </div>
    </div>

    <aside class="snapshot" aria-label="Operational snapshot">
      <div class="snapshot-header">
        <span>Operational Snapshot</span>
        <time datetime="<?php echo esc_attr(current_time('Y-m-d')); ?>">Updated <?php echo esc_html(date_i18n('M j, Y')); ?></time>
      </div>
      <a class="snapshot-row" href="#events">
        <span class="row-icon">
          <?php
          if ($next_event) {
              echo esc_html(date_i18n('d', strtotime(get_post_meta($next_event->ID, '_zla_event_date', true))));
          } else {
              echo '--';
          }
          ?>
        </span>
        <span>
          <strong><?php echo $next_event ? esc_html(get_the_title($next_event)) : 'Next Upcoming Event'; ?></strong>
          <small>
            <?php
            if ($next_event) {
                $date = get_post_meta($next_event->ID, '_zla_event_date', true);
                $time = get_post_meta($next_event->ID, '_zla_event_time', true) ?: 'TBD';
                $location = get_post_meta($next_event->ID, '_zla_event_location', true) ?: 'TBD';
                echo esc_html(date_i18n('M j, Y', strtotime($date)) . ' | ' . $time . ' | ' . $location);
            } else {
                echo 'Add an event in WordPress admin';
            }
            ?>
          </small>
        </span>
      </a>
      <a class="snapshot-row" href="<?php echo esc_url(home_url('/training/')); ?>">
        <span class="row-icon">TR</span>
        <span>
          <strong>Training Resources</strong>
          <small>MOUs, briefings, refreshers, and classroom items</small>
        </span>
      </a>
      <a class="snapshot-row" href="<?php echo esc_url(get_theme_mod('natca_zla_ap_tracker_url', 'https://natcazla.com/ap.html')); ?>">
        <span class="row-icon">AP</span>
        <span>
          <strong>Airspace Tracker</strong>
          <small>Open the Airspace and Procedures tracker</small>
        </span>
      </a>
    </aside>
  </section>

  <section id="events" class="section split-section">
    <div class="section-heading">
      <p>01 // Events</p>
      <h2>Local Schedule</h2>
    </div>
    <div class="data-panel">
      <div class="table-head">
        <span>Date</span>
        <span>Time</span>
        <span>Event</span>
        <span>Location</span>
      </div>
      <?php if ($events->have_posts()) : ?>
        <?php while ($events->have_posts()) : $events->the_post(); ?>
          <?php
          $date = get_post_meta(get_the_ID(), '_zla_event_date', true);
          $time = get_post_meta(get_the_ID(), '_zla_event_time', true);
          $location = get_post_meta(get_the_ID(), '_zla_event_location', true);
          ?>
          <a class="table-row" href="<?php the_permalink(); ?>">
            <span><?php echo esc_html($date ? date_i18n('M j', strtotime($date)) : 'TBD'); ?></span>
            <span><?php echo esc_html($time ?: 'TBD'); ?></span>
            <strong><?php the_title(); ?></strong>
            <span><?php echo esc_html($location ?: 'TBD'); ?></span>
          </a>
        <?php endwhile; wp_reset_postdata(); ?>
      <?php else : ?>
        <p class="empty-row">No upcoming events are currently listed.</p>
      <?php endif; ?>
    </div>
  </section>

  <section id="reps" class="section">
    <div class="section-heading">
      <p>02 // Reps</p>
      <h2>Representative Directory</h2>
    </div>
    <div class="rep-grid">
      <?php
      $reps = new WP_Query([
          'post_type' => 'zla_rep',
          'posts_per_page' => 4,
          'orderby' => 'menu_order date',
          'order' => 'ASC',
      ]);
      ?>
      <?php if ($reps->have_posts()) : ?>
        <?php while ($reps->have_posts()) : $reps->the_post(); ?>
          <?php
          $role = get_post_meta(get_the_ID(), '_zla_rep_role', true) ?: get_the_title();
          $initials = get_post_meta(get_the_ID(), '_zla_rep_initials', true) ?: 'ZL';
          $phone = get_post_meta(get_the_ID(), '_zla_rep_phone', true);
          $email = get_post_meta(get_the_ID(), '_zla_rep_email', true);
          ?>
          <article class="rep-card">
            <span class="avatar"><?php echo esc_html($initials); ?></span>
            <h3><?php echo esc_html($role); ?></h3>
            <p class="rep-name"><?php the_title(); ?></p>
            <p><?php echo esc_html(wp_strip_all_tags(get_the_content())); ?></p>
            <p class="rep-meta"><?php echo esc_html(trim(($phone ?: '') . ($phone && $email ? ' | ' : '') . ($email ?: '')) ?: 'Phone and email can be added here when ready.'); ?></p>
            <a href="#contact">Contact office</a>
          </article>
        <?php endwhile; wp_reset_postdata(); ?>
      <?php endif; ?>
    </div>
  </section>

  <section id="training" class="section split-section">
    <div class="section-heading">
      <p>03 // Training</p>
      <h2>Current Resources</h2>
    </div>
    <div class="resource-list">
      <?php
      $resources = new WP_Query([
          'post_type' => 'zla_resource',
          'posts_per_page' => 3,
          'orderby' => 'date',
          'order' => 'ASC',
      ]);
      ?>
      <?php if ($resources->have_posts()) : ?>
        <?php while ($resources->have_posts()) : $resources->the_post(); ?>
          <?php $resource_url = get_post_meta(get_the_ID(), '_zla_resource_url', true) ?: get_permalink(); ?>
          <a href="<?php echo esc_url($resource_url); ?>">
            <strong><?php the_title(); ?></strong>
            <span><?php echo esc_html(wp_trim_words(wp_strip_all_tags(get_the_content()), 18)); ?></span>
          </a>
        <?php endwhile; wp_reset_postdata(); ?>
      <?php else : ?>
        <p class="empty-row">No training resources are currently listed.</p>
      <?php endif; ?>
    </div>
  </section>

  <section id="lse" class="section">
    <div class="section-heading">
      <p>04 // LSC</p>
      <h2>Local Safety Engagement</h2>
    </div>
    <div class="status-board">
      <article>
        <span class="status teal">Open</span>
        <h3>Safety Lessons</h3>
        <p>Shared learning from local events, operational trends, and facility discussions.</p>
      </article>
      <article>
        <span class="status gold">Review</span>
        <h3>Member Feedback</h3>
        <p>Collect and route safety concerns to the right local and national channels.</p>
      </article>
      <article>
        <span class="status magenta">Action</span>
        <h3>Follow-Up Items</h3>
        <p>Track safety recommendations and keep members informed on progress.</p>
      </article>
    </div>
  </section>

  <section id="contact" class="section contact-section">
    <div>
      <div class="section-heading">
        <p>06 // Contact</p>
        <h2>Reach NATCA ZLA</h2>
      </div>
      <p>
        Use this hub for general local inquiries, representative routing, training resources,
        and airspace procedure coordination requests.
      </p>
      <dl class="contact-details">
        <div>
          <dt>Email</dt>
          <dd><a href="mailto:<?php echo esc_attr(get_theme_mod('natca_zla_contact_email', 'zla@natca.net')); ?>"><?php echo esc_html(get_theme_mod('natca_zla_contact_email', 'zla@natca.net')); ?></a></dd>
        </div>
        <div>
          <dt>Facility</dt>
          <dd><?php echo esc_html(get_theme_mod('natca_zla_facility', 'Los Angeles ARTCC, Palmdale, California')); ?></dd>
        </div>
      </dl>
    </div>

    <form class="contact-form">
      <label>Name <input type="text" name="name" autocomplete="name" /></label>
      <label>Email <input type="email" name="email" autocomplete="email" /></label>
      <label>
        Topic
        <select name="topic">
          <option>Representative question</option>
          <option>Event information</option>
          <option>Training resource</option>
          <option>LSC or safety</option>
          <option>Airspace coordination</option>
        </select>
      </label>
      <label>Message <textarea name="message" rows="4"></textarea></label>
      <button class="button primary" type="submit">Send Message</button>
      <p class="form-note" aria-live="polite"></p>
    </form>
  </section>
</main>

<?php get_footer(); ?>
