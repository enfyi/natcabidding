<?php get_header(); ?>

<main class="page-main">
  <?php while (have_posts()) : the_post(); ?>
    <?php $post_type_object = get_post_type_object(get_post_type()); ?>
    <article class="section page-hero single-entry">
      <div class="section-heading">
        <p><?php echo esc_html($post_type_object ? $post_type_object->labels->singular_name : 'Update'); ?></p>
        <h1><?php the_title(); ?></h1>
      </div>
      <div class="single-meta">
        <?php if (get_post_type() === 'zla_event') : ?>
          <?php
          $date = get_post_meta(get_the_ID(), '_zla_event_date', true);
          $time = get_post_meta(get_the_ID(), '_zla_event_time', true);
          $location = get_post_meta(get_the_ID(), '_zla_event_location', true);
          ?>
          <p><?php echo esc_html(trim(($date ? date_i18n('M j, Y', strtotime($date)) : '') . ' | ' . ($time ?: 'TBD') . ' | ' . ($location ?: 'TBD'), ' |')); ?></p>
        <?php endif; ?>
        <?php the_content(); ?>
      </div>
    </article>
  <?php endwhile; ?>
</main>

<?php get_footer(); ?>
