    <footer class="site-footer">
      <?php
      $contact_email = get_theme_mod('natca_zla_contact_email', 'zla@natca.net');
      $facility = get_theme_mod('natca_zla_facility', 'Los Angeles ARTCC, Palmdale, California');
      $facebook = get_theme_mod('natca_zla_facebook_url');
      $instagram = get_theme_mod('natca_zla_instagram_url');
      $ap_tracker = get_theme_mod('natca_zla_ap_tracker_url', 'https://natcazla.com/ap.html');
      ?>

      <div class="footer-inner">
        <div class="footer-brand">
          <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/logo-5v2a.png'); ?>" alt="" />
          <div>
            <span>NATCA ZLA</span>
            <small>Los Angeles Center</small>
          </div>
          <p>
            A local member hub for ZLA updates, events, training resources, LSC information,
            and airspace procedure coordination.
          </p>
        </div>

        <nav class="footer-links" aria-label="<?php esc_attr_e('Footer site links', 'natca-zla'); ?>">
          <h2>Local</h2>
          <a href="<?php echo esc_url(home_url('/#events')); ?>">Events</a>
          <a href="<?php echo esc_url(home_url('/#reps')); ?>">Representatives</a>
          <a href="<?php echo esc_url(home_url('/training/')); ?>">Training</a>
          <a href="<?php echo esc_url(home_url('/#lse')); ?>">LSC</a>
          <a href="<?php echo esc_url(home_url('/#airspace')); ?>">Airspace</a>
          <a href="<?php echo esc_url($ap_tracker); ?>">Airspace Tracker</a>
        </nav>

        <nav class="footer-links" aria-label="<?php esc_attr_e('External links', 'natca-zla'); ?>">
          <h2>External</h2>
          <a href="https://www.natca.org/" target="_blank" rel="noopener">NATCA National</a>
          <a href="https://www.faa.gov/" target="_blank" rel="noopener">FAA</a>
          <a href="https://www.faa.gov/air_traffic" target="_blank" rel="noopener">FAA Air Traffic</a>
          <a href="https://www.osha.gov/" target="_blank" rel="noopener">OSHA</a>
          <a href="#">Add link</a>
        </nav>

        <div class="footer-contact">
          <h2>Facility</h2>
          <address>
            2555 E. Ave P<br />
            Palmdale, CA 93550<br />
            <?php echo esc_html($facility); ?>
          </address>
          <a href="mailto:<?php echo esc_attr($contact_email); ?>"><?php echo esc_html($contact_email); ?></a>
          <div class="social-links" aria-label="<?php esc_attr_e('Social links', 'natca-zla'); ?>">
            <a href="<?php echo esc_url($facebook ?: '#'); ?>" aria-label="Facebook" <?php echo $facebook ? 'target="_blank" rel="noopener"' : ''; ?>>
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M14 8.2V6.9c0-.7.5-.9.9-.9H17V2.3A27 27 0 0 0 14 2c-3 0-5 1.8-5 5.1v1.1H6v4h3V22h4.1v-9.8h3.1l.6-4H13V7.5c0-.8.3-1.3 1-1.3Z" />
              </svg>
            </a>
            <a href="<?php echo esc_url($instagram ?: '#'); ?>" aria-label="Instagram" <?php echo $instagram ? 'target="_blank" rel="noopener"' : ''; ?>>
              <svg viewBox="0 0 24 24" aria-hidden="true">
                <path d="M7.8 2h8.4A5.8 5.8 0 0 1 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8A5.8 5.8 0 0 1 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2Zm0 2A3.8 3.8 0 0 0 4 7.8v8.4A3.8 3.8 0 0 0 7.8 20h8.4a3.8 3.8 0 0 0 3.8-3.8V7.8A3.8 3.8 0 0 0 16.2 4H7.8Zm8.9 2.1a1.2 1.2 0 1 1 0 2.4 1.2 1.2 0 0 1 0-2.4ZM12 7.3a4.7 4.7 0 1 1 0 9.4 4.7 4.7 0 0 1 0-9.4Zm0 2a2.7 2.7 0 1 0 0 5.4 2.7 2.7 0 0 0 0-5.4Z" />
              </svg>
            </a>
          </div>
        </div>
      </div>

      <div class="footer-bottom">
        <span>&copy; <?php echo esc_html(date_i18n('Y')); ?> NATCA ZLA</span>
        <span>Los Angeles Center</span>
      </div>
    </footer>
    <?php wp_footer(); ?>
  </body>
</html>
